import os
from openai import OpenAI
import numpy as np

class DiseaseAnalyzer:
    def __init__(self):
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.normal_ranges = {
            "Hemoglobin": {"male": (13.5, 17.5), "female": (12.0, 15.5)},
            "WBC": (4500, 11000),
            "Platelets": (150000, 450000),
            "Glucose": (70, 100),
            "Creatinine": (0.7, 1.3),
            "ALT": (7, 56),
            "AST": (10, 40)
        }

    def analyze_blood_report(self, blood_data):
        abnormalities = []
        for param, value in blood_data.items():
            if param in self.normal_ranges:
                range_values = self.normal_ranges[param]
                if isinstance(range_values, dict):  
                  
                    range_values = range_values["male"]
                
                if value < range_values[0]:
                    abnormalities.append(f"Low {param}")
                elif value > range_values[1]:
                    abnormalities.append(f"High {param}")

        return abnormalities

    def get_disease_prediction(self, xray_findings, blood_abnormalities):
        
        combined_findings = {
            "xray_findings": xray_findings,
            "blood_abnormalities": blood_abnormalities
        }

        try:
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": "You are a medical analysis expert. Based on the provided X-ray findings and blood test abnormalities, provide a detailed analysis of potential conditions. Format your response as JSON with 'conditions', 'description', 'severity', and 'recommendations' fields."
                    },
                    {
                        "role": "user",
                        "content": str(combined_findings)
                    }
                ],
                response_format={"type": "json_object"}
            )
            
            return response.choices[0].message.content
        except Exception as e:
            return {
                "conditions": ["Unable to analyze conditions"],
                "description": f"Error in analysis: {str(e)}",
                "severity": "unknown",
                "recommendations": ["Please consult with a healthcare provider"]
            }

    def generate_comparative_data(self, blood_data):
        """Generate comparative data for blood parameters"""
        parameters = list(blood_data.keys())
        normal_values = []
        patient_values = []
        lower_bounds = []
        upper_bounds = []

        for param in parameters:
            if param in self.normal_ranges:
                range_values = self.normal_ranges[param]
                if isinstance(range_values, dict):
                    range_values = range_values["male"]  
                

                normal_value = np.mean(range_values)
                
                normal_values.append(normal_value)
                patient_values.append(blood_data[param])
                lower_bounds.append(range_values[0])
                upper_bounds.append(range_values[1])

        return {
            "parameters": parameters,
            "normal_values": normal_values,
            "patient_values": patient_values,
            "lower_bounds": lower_bounds,
            "upper_bounds": upper_bounds
        }
