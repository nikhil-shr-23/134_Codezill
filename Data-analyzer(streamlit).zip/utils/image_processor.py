import numpy as np
import cv2
from PIL import Image
import io

class XRayAnalyzer:
    def __init__(self):
        self.condition_scores = {
            "Lungs/Heart": ["pneumonia", "cardiomegaly"],
            "Abdomen": ["intestinal_obstruction", "kidney_stones"],
            "Bones": ["fracture", "arthritis"]
        }

    def analyze(self, image_file, department):
        #
        image_bytes = image_file.read()
        nparr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)

       
        original_height, original_width = img.shape


        target_size = (512, 512)
        img_resized = cv2.resize(img, target_size)
        img_processed = cv2.equalizeHist(img_resized)

       
        heatmap = self._generate_heatmap(img_processed, department)

       
        heatmap = cv2.resize(heatmap, (original_width, original_height))

     
        findings = self._detect_anomalies(img_processed, department)

        heatmap_normalized = cv2.normalize(heatmap, None, 0, 1, cv2.NORM_MINMAX)

        return {
            "findings": findings,
            "heatmap": heatmap_normalized.tolist(),
            "score": float(np.mean([float(f.split(": ")[1]) for f in findings])),
            "department": department,
            "dimensions": {"width": original_width, "height": original_height}
        }

    def _generate_heatmap(self, img, department):

        height, width = img.shape
        heatmap = np.zeros((height, width))


        if department == "Lungs/Heart":

            edges = cv2.Canny(img, 100, 200)
            blur = cv2.GaussianBlur(img, (15, 15), 0)
            diff = cv2.absdiff(img, blur)

            
            heatmap = edges.astype(float) * 0.5 + diff.astype(float)

            # Enhancing central chest region
            center_mask = np.zeros((height, width))
            cv2.circle(center_mask, (width//2, height//2), min(width, height)//3, 1, -1)
            heatmap *= (1 + center_mask)

        elif department == "Abdomen":
            # Focus on soft tissue variations
            blur = cv2.GaussianBlur(img, (21, 21), 0)
            diff = cv2.absdiff(img, blur)

            # Create gradient magnitude map
            sobelx = cv2.Sobel(img, cv2.CV_64F, 1, 0, ksize=3)
            sobely = cv2.Sobel(img, cv2.CV_64F, 0, 1, ksize=3)
            gradient_magnitude = np.sqrt(sobelx**2 + sobely**2)

            # Combine difference map with gradient magnitude
            heatmap = diff.astype(float) * 0.7 + gradient_magnitude * 0.3

        else:  # Bones
            # Enhance bone structures using morphological operations
            kernel = np.ones((5,5), np.uint8)
            bone_mask = cv2.morphologyEx(img, cv2.MORPH_TOPHAT, kernel)

            # Apply adaptive thresholding
            thresh = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                         cv2.THRESH_BINARY, 11, 2)

            # Combine bone mask with thresholded image
            heatmap = bone_mask.astype(float) * 0.6 + thresh.astype(float) * 0.4

        # Apply final smoothing
        heatmap = cv2.GaussianBlur(heatmap, (15, 15), 0)
        return heatmap

    def _detect_anomalies(self, img, department):
        """Detect anomalies and calculate probability scores"""
        conditions = self.condition_scores[department]
        findings = []

        # Simulate detection with randomized probabilities for demo
        # In a real implementation, this would use a trained ML model
        for condition in conditions:
            
            prob = np.random.uniform(0.1, 0.9)
            findings.append(f"{condition}: {prob:.2f}")

        return findings