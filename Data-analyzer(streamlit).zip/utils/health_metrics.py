import numpy as np
from datetime import datetime, timedelta

class HealthScorer:
    def __init__(self):
        self.risk_levels = ["Low", "Moderate", "High"]
        self.recommendation_templates = [
            "Schedule regular check-ups",
            "Maintain a balanced diet",
            "Exercise regularly",
            "Monitor vital signs",
            "Get adequate sleep"
        ]
    
    def calculate_overall_score(self):
        # Simulate health score calculation
        return np.random.randint(60, 100)
    
    def get_risk_level(self):
        score = self.calculate_overall_score()
        if score >= 80:
            return "Low"
        elif score >= 60:
            return "Moderate"
        return "High"
    
    def get_next_checkup(self):
        risk = self.get_risk_level()
        today = datetime.now()
        
        if risk == "High":
            next_date = today + timedelta(days=30)
        elif risk == "Moderate":
            next_date = today + timedelta(days=90)
        else:
            next_date = today + timedelta(days=180)
            
        return next_date.strftime("%Y-%m-%d")
    
    def get_recommendations(self):
        risk = self.get_risk_level()
        num_recommendations = 5 if risk == "High" else 3
        return np.random.choice(
            self.recommendation_templates,
            size=num_recommendations,
            replace=False
        )
