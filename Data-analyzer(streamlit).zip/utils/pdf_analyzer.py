import pandas as pd
import numpy as np

class BloodReportAnalyzer:
    def __init__(self):
        self.reference_ranges = {
            "Hemoglobin": (13.5, 17.5),
            "WBC": (4500, 11000),
            "Platelets": (150000, 450000),
            "Glucose": (70, 100),
            "Creatinine": (0.7, 1.3),
            "ALT": (7, 56),
            "AST": (10, 40),
            "Total Bilirubin": (0.3, 1.2),
            "Albumin": (3.5, 5.5)
        }

    def analyze(self, pdf_file):
        # Simulate PDF extraction with more comprehensive data
        simulated_data = {
            "Hemoglobin": np.random.uniform(12, 18),
            "WBC": np.random.uniform(4000, 12000),
            "Platelets": np.random.uniform(140000, 460000),
            "Glucose": np.random.uniform(65, 110),
            "Creatinine": np.random.uniform(0.6, 1.4),
            "ALT": np.random.uniform(5, 60),
            "AST": np.random.uniform(8, 45),
            "Total Bilirubin": np.random.uniform(0.2, 1.4),
            "Albumin": np.random.uniform(3.0, 6.0)
        }

        # Create results DataFrame
        metrics = []
        for param, value in simulated_data.items():
            ref_range = self.reference_ranges[param]
            if value < ref_range[0]:
                status = "Low"
            elif value > ref_range[1]:
                status = "High"
            else:
                status = "Normal"

            metrics.append({
                "Parameter": param,
                "Value": value,
                "Reference Range": f"{ref_range[0]}-{ref_range[1]}",
                "Status": status
            })

        return {
            "metrics": pd.DataFrame(metrics),
            "raw_data": simulated_data
        }