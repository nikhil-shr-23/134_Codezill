import pandas as pd
import numpy as np

class HospitalAnalyzer:
    def __init__(self, hospital_data):
        self.hospitals = hospital_data
        
    def get_recommendations(self, state=None, department=None, max_results=10):
        filtered_df = self.hospitals.copy()
        
        if state:
            filtered_df = filtered_df[filtered_df['State'] == state]
            
        if department:
            filtered_df = filtered_df.sort_values(by=[department, 'Rating_Service'],
                                                ascending=[True, False])
            
        # Normalize and calculate composite score
        filtered_df['price_score'] = 1 - (filtered_df[department] - 
                                        filtered_df[department].min()) / \
                                   (filtered_df[department].max() - 
                                    filtered_df[department].min())
        
        filtered_df['composite_score'] = (filtered_df['price_score'] * 0.4 + 
                                        filtered_df['Rating_Service'] * 0.6)
        
        return filtered_df.head(max_results)[['Hospital_Name', 'City', 'State',
                                            department, 'Rating_Service',
                                            'composite_score']]
