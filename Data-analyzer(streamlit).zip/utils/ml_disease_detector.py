import torch
import torch.nn as nn
import torchvision.models as models
import torchvision.transforms as transforms
from sklearn.ensemble import RandomForestClassifier
import numpy as np
import pickle
import os

class XRayNet(nn.Module):
    def __init__(self, num_classes=6):
        super(XRayNet, self).__init__()
        self.resnet = models.resnet18(pretrained=True)
        self.resnet.fc = nn.Linear(512, num_classes)

    def forward(self, x):
        return self.resnet(x)

class DiseaseDetector:
    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.xray_model = XRayNet().to(self.device)
        self.blood_model = RandomForestClassifier()
        self.blood_params = [
            "WBC Count", "Hemoglobin", "RBC Count", "Hematocrit",
            "MCV", "MCH", "MCHC", "RDW", "Platelet Count", "ESR"
        ]
        self.reference_ranges = {
            "WBC Count": (4.5, 11.0),  # 10^3/µL
            "Hemoglobin": (13.5, 17.5),  # g/dL
            "RBC Count": (4.5, 5.9),  # 10^6/µL
            "Hematocrit": (41.0, 53.0),  # %
            "MCV": (80.0, 100.0),  # fL
            "MCH": (27.0, 33.0),  # pg
            "MCHC": (32.0, 36.0),  # g/dL
            "RDW": (11.5, 14.5),  # %
            "Platelet Count": (150.0, 450.0),  # 10^3/µL
            "ESR": (0.0, 20.0)  # mm/hr
        }

        # Initialize models
        self._initialize_models()

    def generate_comparative_data(self, patient_data):
        """Generate comparative data for visualization"""
        normal_values = []
        patient_values = []
        lower_bounds = []
        upper_bounds = []
        parameters = list(self.reference_ranges.keys())

        for param in parameters:
            lower, upper = self.reference_ranges[param]
            normal_value = (lower + upper) / 2
            patient_value = patient_data.get(param, np.random.uniform(lower * 0.8, upper * 1.2))

            normal_values.append(normal_value)
            patient_values.append(patient_value)
            lower_bounds.append(lower)
            upper_bounds.append(upper)

        return {
            "parameters": parameters,
            "normal_values": normal_values,
            "patient_values": patient_values,
            "lower_bounds": lower_bounds,
            "upper_bounds": upper_bounds
        }

    def _initialize_models(self):
        """Initialize or load pre-trained models"""
        X_blood = np.random.rand(1000, 10)  # Match number of blood parameters
        y_blood = np.random.randint(0, 3, 1000)  # 3 severity levels
        self.blood_model.fit(X_blood, y_blood)

        os.makedirs('models', exist_ok=True)
        with open('models/blood_model.pkl', 'wb') as f:
            pickle.dump(self.blood_model, f)

    def analyze_blood_report(self, blood_data):
        """Analyze blood report and detect abnormalities"""
        abnormalities = []
        features = []
        conditions = []

        reference_ranges = {
            'WBC': {'low': 4500, 'high': 11000},
            'RBC': {'low': 4.5, 'high': 6.0},
            'Hemoglobin': {'low': 13.5, 'high': 17.5},
            'Hematocrit': {'low': 41, 'high': 50},
            'Platelets': {'low': 150000, 'high': 450000},
            'MCV': {'low': 80, 'high': 96},
            'MCH': {'low': 27, 'high': 33},
            'MCHC': {'low': 33, 'high': 36},
            'RDW': {'low': 11.5, 'high': 14.5},
            'Glucose': {'low': 70, 'high': 100},
            'Creatinine': {'low': 0.7, 'high': 1.3},
            'ALT': {'low': 7, 'high': 56},
            'AST': {'low': 10, 'high': 40},
            'Total Bilirubin': {'low': 0.3, 'high': 1.2},
            'Albumin': {'low': 3.5, 'high': 5.5}
        }

        for param, value in blood_data.items():
            if param in reference_ranges:
                features.append(value)
                ranges = reference_ranges[param]

                if value < ranges['low']:
                    abnormalities.append(f"Low {param}")
                    conditions.append({
                        'parameter': param,
                        'status': 'Low',
                        'value': value,
                        'range': f"{ranges['low']} - {ranges['high']}",
                        'implications': self._get_condition_implications(param, 'low')
                    })
                elif value > ranges['high']:
                    abnormalities.append(f"High {param}")
                    conditions.append({
                        'parameter': param,
                        'status': 'High',
                        'value': value,
                        'range': f"{ranges['low']} - {ranges['high']}",
                        'implications': self._get_condition_implications(param, 'high')
                    })

        severity = self._calculate_severity(conditions)
        return {
            "abnormalities": abnormalities,
            "conditions": conditions,
            "severity": severity,
            "features": features
        }

    def _get_condition_implications(self, param, level):
        implications = {
            'WBC': {
                'high': 'May indicate infection, inflammation, leukemia, stress, or smoking',
                'low': 'Could suggest viral infections, bone marrow disorders, or autoimmune diseases'
            },
            'RBC': {
                'high': 'May indicate dehydration, lung disease, or heart disease',
                'low': 'Could suggest blood loss, iron deficiency, or bone marrow problems'
            },
            'Hemoglobin': {
                'high': 'May indicate dehydration, lung disease, or smoking',
                'low': 'Could suggest anemia, blood loss, or nutritional deficiencies'
            },
            'Platelets': {
                'high': 'May indicate inflammation, infection, or iron deficiency',
                'low': 'Could suggest bleeding disorders, bone marrow problems, or viral infections'
            },
            'Glucose': {
                'high': 'May indicate diabetes or prediabetes',
                'low': 'Could suggest hypoglycemia or metabolic disorders'
            }
        }
        return implications.get(param, {}).get(level, 'Requires medical evaluation')

    def _calculate_severity(self, conditions):
        if len(conditions) >= 3:
            return 2  # High severity
        elif len(conditions) >= 1:
            return 1  # Moderate severity
        return 0  # Low severity

    def process_xray(self, image_tensor, department):
        self.xray_model.eval()
        with torch.no_grad():
            output = self.xray_model(image_tensor)
            probabilities = torch.sigmoid(output)

        conditions = {
            "Lungs/Heart": ["pneumonia", "cardiomegaly"],
            "Abdomen": ["intestinal_obstruction", "kidney_stones"],
            "Bones": ["fracture", "arthritis"]
        }
        dept_conditions = conditions[department]
        predictions = []
        for i, condition in enumerate(dept_conditions):
            predictions.append(f"{condition}: {float(probabilities[0][i])}")

        return predictions

    def get_combined_analysis(self, xray_findings, blood_analysis):
        """Combine X-ray and blood analysis for comprehensive diagnosis"""
        conditions = []
        severity_levels = ["Low", "Moderate", "High"]
        severity = severity_levels[blood_analysis["severity"]]

        for finding in xray_findings:
            condition, prob = finding.split(": ")
            if float(prob) > 0.5:
                conditions.append(condition)

        conditions.extend(blood_analysis["abnormalities"])

        diseases = self._predict_diseases(conditions, blood_analysis["features"])

        return {
            "conditions": conditions,
            "diseases": diseases,
            "severity": severity,
            "description": self._generate_description(diseases, severity),
            "recommendations": self._generate_recommendations(diseases, severity)
        }

    def _predict_diseases(self, conditions, blood_features):
        diseases = []
        descriptions = []

        blood_conditions = {
            "High WBC Count": ["Bacterial Infection", "Inflammation", "Leukemia", "Stress", "Steroid use", "Allergic reactions"],
            "Low WBC Count": ["Viral infections", "Bone marrow failure", "HIV/AIDS", "Autoimmune diseases", "Severe infections", "Cancer treatment"],
            "High Hemoglobin": ["Dehydration", "Lung disease", "Polycythemia vera", "Heart disease", "Living at high altitude"],
            "Low Hemoglobin": ["Iron deficiency anemia", "Chronic disease", "Blood loss", "Kidney disease", "Thalassemia", "Vitamin B12 deficiency"],
            "High RBC Count": ["Dehydration", "Lung disease", "Heart disease", "Polycythemia vera", "Kidney tumors"],
            "Low RBC Count": ["Blood loss", "Iron deficiency", "Bone marrow failure", "Chronic kidney disease", "Hemolysis"],
            "High Platelet Count": ["Inflammation", "Cancer", "Iron deficiency", "Post-splenectomy", "Rheumatoid arthritis"],
            "Low Platelet Count": ["Bone marrow problems", "Viral infections", "Autoimmune diseases", "Leukemia", "ITP", "Medication side effects"],
            "High ESR": ["Infection", "Inflammation", "Cancer", "Chronic disease", "Rheumatoid arthritis", "Temporal arteritis"],
            "Low ESR": ["Polycythemia vera", "Sickle cell disease", "Severe liver disease", "Congestive heart failure"]
        }

        for condition in conditions:
            condition = condition.strip()
            for key, possible_diseases in blood_conditions.items():
                if condition.startswith(key) or key in condition:
                    diseases.extend(possible_diseases)
                    descriptions.append(f"{condition} may indicate: {', '.join(possible_diseases)}")

        if "pneumonia" in str(conditions).lower():
            diseases.append("Pneumonia")
        if "cardiomegaly" in str(conditions).lower():
            diseases.append("Cardiomegaly")

        self.detailed_descriptions = descriptions
        return list(set(diseases)) if diseases else ["No significant diseases detected"]

    def _generate_description(self, diseases, severity):
        if diseases[0] == "No significant diseases detected":
            return "No significant medical conditions detected. Continue regular health monitoring."

        description = f"Analysis indicates {severity.lower()} risk level.\n\n"
        if hasattr(self, 'detailed_descriptions'):
            description += "Detailed Analysis:\n"
            for detail in self.detailed_descriptions:
                description += f"• {detail}\n"

        description += f"\nPotential conditions identified: "
        if len(diseases) == 1:
            description += f"{diseases[0]}."
        else:
            description += ", ".join(diseases[:-1]) + f" and {diseases[-1]}."
        return description

    def _generate_recommendations(self, diseases, severity):
        recommendations = []

        if severity == "High":
            recommendations.append("Urgent medical consultation recommended")
        elif severity == "Moderate":
            recommendations.append("Schedule follow-up with healthcare provider")
        else:
            recommendations.append("Regular health check-ups recommended")

        for disease in diseases:
            if disease == "Anemia":
                recommendations.append("Consider iron supplementation and dietary changes")
            elif disease == "Infection":
                recommendations.append("Monitor temperature and symptoms")
            elif disease == "Thrombocytopenia":
                recommendations.append("Avoid activities with risk of injury")
            elif disease == "Inflammation":
                recommendations.append("Anti-inflammatory medications may be needed")

        return recommendations