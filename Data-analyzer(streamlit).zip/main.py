import streamlit as st
import pandas as pd
import numpy as np
from utils.hospital_analysis import HospitalAnalyzer
from utils.image_processor import XRayAnalyzer
from utils.pdf_analyzer import BloodReportAnalyzer
from utils.ml_disease_detector import DiseaseDetector
from utils.health_metrics import HealthScorer
import plotly.express as px
import plotly.graph_objects as go


st.set_page_config(
    page_title="MedBridge",
    page_icon="🏥",
    layout="wide"
)


st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

    * {
        font-family: 'Inter', sans-serif;
    }
    .main {
        padding: 0rem 1rem;
    }
    .stTitle {
        font-size: 3rem !important;
        text-align: center;
        color: #0066cc;
        margin-bottom: 2rem;
    }
    .stTabs {
        background-color: white;
        padding: 1rem;
        border-radius: 0.5rem;
        box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }
    .uploadSection {
        border: 2px dashed #cccccc;
        border-radius: 5px;
        padding: 2rem;
        text-align: center;
        margin: 1rem 0;
    }
    .stButton {
        text-align: center;
    }
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1rem;
        background-color: white;
        margin-bottom: 2rem;
    }
    .metrics-container {
        background-color: white;
        padding: 1.5rem;
        border-radius: 0.5rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        margin: 1rem 0;
    }
    .metric-normal {
        color: #00cc66;
        font-weight: 500;
    }
    .metric-abnormal {
        color: #ff4444;
        font-weight: 500;
    }
</style>
""", unsafe_allow_html=True)

# Initialize components
@st.cache_data
def load_hospital_data():
    return pd.read_csv("data/hospitals.csv")

hospitals_df = load_hospital_data()
hospital_analyzer = HospitalAnalyzer(hospitals_df)
xray_analyzer = XRayAnalyzer()
blood_analyzer = BloodReportAnalyzer()
disease_detector = DiseaseDetector()
health_scorer = HealthScorer()

# yaha pe session state ko initialize kiya hai 
if 'xray_results' not in st.session_state:
    st.session_state.xray_results = None
if 'blood_results' not in st.session_state:
    st.session_state.blood_results = None

# Header and Logo
st.image("assets/medbridge_logo.svg", use_column_width=True)
st.markdown("<p style='text-align: center; color: #666666;'>Advanced medical analysis powered by artificial intelligence</p>", unsafe_allow_html=True)

# Navigation
nav_col1, nav_col2, nav_col3 = st.columns([1,1,1])
with nav_col2:
    nav = st.radio("", ["Home", "Dashboard", "Help"], horizontal=True)

if nav == "Home":
    # Main content
    tab1, tab2 = st.tabs(["X-ray Analysis", "Medical Reports (PDF)"])

    with tab1:
        st.markdown("<div class='uploadSection'>", unsafe_allow_html=True)
        st.write("Upload X-ray images for instant AI-powered analysis with heatmap visualization")
        uploaded_file = st.file_uploader("", type=['png', 'jpg', 'jpeg'], key="xray")
        department = st.selectbox(
            "Select Department",
            ["Lungs/Heart", "Abdomen", "Bones"]
        )
        st.markdown("</div>", unsafe_allow_html=True)

        if uploaded_file:
            with st.spinner('Analyzing X-ray image... Please wait.'):
                analysis_results = xray_analyzer.analyze(uploaded_file, department)
                st.session_state.xray_results = analysis_results

            col1, col2 = st.columns(2)
            with col1:
                st.image(uploaded_file, caption="Original X-Ray", use_container_width=True)

            with col2:
                
                fig = go.Figure()

              # here is the heatmap wala part 
                fig.add_trace(go.Heatmap(
                    z=analysis_results['heatmap'],
                    colorscale=[
                        [0, 'rgba(0,0,255,0)'],      # Transparent for low values
                        [0.5, 'rgba(255,255,0,0.5)'], # Yellow for medium values
                        [1, 'rgba(255,0,0,0.8)']      # Red for high values
                    ],
                    showscale=True,
                    name="Anomaly Detection"
                ))

                # Update layout for better visualization
                fig.update_layout(
                    title={
                        'text': "X-Ray Analysis Heatmap",
                        'y':0.95,
                        'x':0.5,
                        'xanchor': 'center',
                        'yanchor': 'top',
                        'font': dict(size=16, family='Inter')
                    },
                    width=400,
                    height=400,
                    paper_bgcolor='rgba(0,0,0,0)',
                    plot_bgcolor='rgba(0,0,0,0)'
                )

                # Remove axes for cleaner look
                fig.update_xaxes(showticklabels=False, showgrid=False)
                fig.update_yaxes(showticklabels=False, showgrid=False)

                st.plotly_chart(fig)

            # Display analysis results in a structured format
            st.markdown("<div class='metrics-container'>", unsafe_allow_html=True)
            st.subheader("Analysis Results")
            st.write(f"Department: {department}")

            # Display overall health score
            score = analysis_results['score'] * 100
            st.markdown(
                f"<h3>Overall Health Score: "
                f"<span style='color: {'green' if score > 70 else 'orange' if score > 50 else 'red'}'>"
                f"{score:.1f}%</span></h3>",
                unsafe_allow_html=True
            )

            # Display findings with progress bars and severity indicators
            st.subheader("Detected Conditions")
            for finding in analysis_results['findings']:
                condition, probability = finding.split(': ')
                prob_float = float(probability)

                # Create color-coded severity indicator
                severity = ("Low Risk" if prob_float < 0.3 else 
                          "Moderate Risk" if prob_float < 0.7 else 
                          "High Risk")
                color = ("green" if prob_float < 0.3 else 
                        "orange" if prob_float < 0.7 else 
                        "red")

                st.markdown(f"**{condition}**")
                col1, col2 = st.columns([7,3])
                with col1:
                    st.progress(prob_float)
                with col2:
                    st.markdown(
                        f"<span style='color: {color}'>{severity}</span>",
                        unsafe_allow_html=True
                    )
            st.markdown("</div>", unsafe_allow_html=True)

    with tab2:
        st.markdown("<div class='uploadSection'>", unsafe_allow_html=True)
        st.write("Upload blood test reports in PDF format for comprehensive analysis")
        uploaded_pdf = st.file_uploader("", type=['pdf'], key="pdf")
        st.markdown("</div>", unsafe_allow_html=True)

        if uploaded_pdf:
            results = blood_analyzer.analyze(uploaded_pdf)
            st.session_state.blood_results = results

            st.markdown("<div class='metrics-container'>", unsafe_allow_html=True)
            st.subheader("Blood Test Results")
            st.dataframe(results['metrics'])
            st.markdown("</div>", unsafe_allow_html=True)

            comparative_data = disease_detector.generate_comparative_data(results['raw_data'])

            # Enhanced blood component visualization
            fig = go.Figure()

            # Add patient values line
            fig.add_trace(go.Scatter(
                x=comparative_data['parameters'],
                y=comparative_data['patient_values'],
                name='Your Results',
                line=dict(color='#0066cc', width=3)
            ))

            # Add normal values line
            fig.add_trace(go.Scatter(
                x=comparative_data['parameters'],
                y=comparative_data['normal_values'],
                name='Normal Range',
                line=dict(color='#00cc66', width=2, dash='dash')
            ))

            # Add reference ranges as shaded areas
            for i, param in enumerate(comparative_data['parameters']):
                fig.add_trace(go.Scatter(
                    x=[param, param],
                    y=[comparative_data['lower_bounds'][i], comparative_data['upper_bounds'][i]],
                    mode='lines',
                    line=dict(color='rgba(0,200,0,0.2)', width=20),
                    showlegend=False,
                    hoverinfo='skip'
                ))

            # Update layout for better visibility
            fig.update_layout(
                title={
                    'text': "Blood Components Analysis",
                    'y':0.95,
                    'x':0.5,
                    'xanchor': 'center',
                    'yanchor': 'top',
                    'font': dict(size=20, family='Inter')
                },
                xaxis_title="Blood Components",
                yaxis_title="Values",
                hovermode='x unified',
                height=600,
                showlegend=True,
                legend=dict(
                    yanchor="top",
                    y=0.99,
                    xanchor="left",
                    x=0.01
                ),
                font=dict(family='Inter'),
                plot_bgcolor='white',
                paper_bgcolor='white',
                xaxis=dict(
                    showgrid=True,
                    gridcolor='rgba(0,0,0,0.1)',
                    tickangle=45
                ),
                yaxis=dict(
                    showgrid=True,
                    gridcolor='rgba(0,0,0,0.1)'
                )
            )

            # Add value annotations
            for i, param in enumerate(comparative_data['parameters']):
                patient_value = comparative_data['patient_values'][i]
                lower_bound = comparative_data['lower_bounds'][i]
                upper_bound = comparative_data['upper_bounds'][i]

                if patient_value < lower_bound:
                    fig.add_annotation(
                        x=param,
                        y=patient_value,
                        text=f"LOW ({patient_value:.1f})",
                        showarrow=True,
                        arrowhead=1,
                        font=dict(color="red", family='Inter')
                    )
                elif patient_value > upper_bound:
                    fig.add_annotation(
                        x=param,
                        y=patient_value,
                        text=f"HIGH ({patient_value:.1f})",
                        showarrow=True,
                        arrowhead=1,
                        font=dict(color="red", family='Inter')
                    )

            st.plotly_chart(fig, use_container_width=True)

            # Blood Analysis Results
            blood_analysis = disease_detector.analyze_blood_report(results['raw_data'])

            st.markdown("<div class='metrics-container'>", unsafe_allow_html=True)
            st.subheader("Blood Analysis Results")

            if blood_analysis['conditions']:
                for condition in blood_analysis['conditions']:
                    if condition['status'] == 'Low':
                        st.error(f"⚠️ {condition['parameter']}: {condition['value']} (Low)")
                    else:
                        st.warning(f"⚠️ {condition['parameter']}: {condition['value']} (High)")

                    st.info(f"Normal Range: {condition['range']}")
                    st.markdown(f"**Potential Implications**: {condition['implications']}")
                    st.markdown("---")
            else:
                st.success("✅ All blood parameters are within normal ranges")

            if blood_analysis['severity'] > 1:
                st.error("⚠️ Multiple abnormalities detected. Please consult a healthcare provider.")
            elif blood_analysis['severity'] == 1:
                st.warning("⚠️ Some abnormalities detected. Consider consulting a healthcare provider.")

            st.markdown("</div>", unsafe_allow_html=True)

elif nav == "Dashboard":
    st.title("Medical Analysis Dashboard")

    tabs = st.tabs(["Health Overview", "Blood Analysis", "Hospital Comparison", "Recommendations"])

    with tabs[0]:
        if st.session_state.blood_results:
            st.subheader("Health Index")
            health_score = health_scorer.calculate_overall_score()

            # Get blood analysis
            blood_analysis = disease_detector.analyze_blood_report(st.session_state.blood_results['raw_data'])

            # Create health index gauge
            fig = go.Figure(go.Indicator(
                mode="gauge+number",
                value=health_score,
                title={'text': "Overall Health Score"},
                gauge={'axis': {'range': [0, 100]},
                       'bar': {'color': "darkblue"},
                       'steps': [
                           {'range': [0, 50], 'color': "red"},
                           {'range': [50, 75], 'color': "yellow"},
                           {'range': [75, 100], 'color': "green"}
                       ]}
            ))
            st.plotly_chart(fig)

            # Health recommendations
            st.subheader("Personalized Health Recommendations")
            col1, col2 = st.columns(2)

            with col1:
                st.markdown("### Recommended Exercises")
                if "Low Hemoglobin" in blood_analysis.get("abnormalities", []):
                    st.markdown("- Light aerobic exercises (walking, swimming)")
                    st.markdown("- Yoga for blood circulation")
                    st.markdown("- Breathing exercises")
                elif "High WBC Count" in blood_analysis.get("abnormalities", []):
                    st.markdown("- Moderate intensity walking")
                    st.markdown("- Gentle stretching")
                    st.markdown("- Tai Chi")
                else:
                    st.markdown("- Regular cardio exercises")
                    st.markdown("- Strength training")
                    st.markdown("- Flexibility exercises")

            with col2:
                st.markdown("### Dietary Recommendations")
                if "Low Hemoglobin" in blood_analysis.get("abnormalities", []):
                    st.markdown("- Iron-rich foods (spinach, lean meats)")
                    st.markdown("- Vitamin C rich fruits")
                    st.markdown("- Avoid tea/coffee with meals")
                elif "High WBC Count" in blood_analysis.get("abnormalities", []):
                    st.markdown("- Anti-inflammatory foods")
                    st.markdown("- Green leafy vegetables")
                    st.markdown("- Probiotic-rich foods")
                else:
                    st.markdown("- Balanced diet with whole grains")
                    st.markdown("- Lean proteins")
                    st.markdown("- Fresh fruits and vegetables")

            # Health Alerts
            st.subheader("Health Alerts")
            alerts = []
            for abnormality in blood_analysis.get("abnormalities", []):
                if "Low" in abnormality:
                    alerts.append({"message": f"🔴 {abnormality} detected", "color": "red"})
                elif "High" in abnormality:
                    alerts.append({"message": f"🟡 {abnormality} detected", "color": "orange"})

            for alert in alerts:
                st.markdown(f"<div style='padding: 10px; background-color: {alert['color']}; color: white; border-radius: 5px; margin: 5px 0;'>{alert['message']}</div>", unsafe_allow_html=True)
        else:
            st.warning("Please complete blood report analysis to view health recommendations.")

    tab1, tab2 = st.tabs(["Blood Analysis", "Hospital Comparison"])

    with tab1:
        if st.session_state.blood_results:
            st.subheader("Blood Component Analysis")

            # Get comparative data
            comparative_data = disease_detector.generate_comparative_data(st.session_state.blood_results['raw_data'])

            # Create animated bar chart
            import plotly.graph_objects as go
            from plotly.subplots import make_subplots

            fig = go.Figure()

            # Add bars for patient values
            fig.add_trace(go.Bar(
                name='Your Results',
                x=comparative_data['parameters'],
                y=comparative_data['patient_values'],
                marker_color='#0066cc'
            ))

            # Add bars for normal values
            fig.add_trace(go.Bar(
                name='Normal Range',
                x=comparative_data['parameters'],
                y=comparative_data['normal_values'],
                marker_color='#00cc66'
            ))

            # Update layout
            fig.update_layout(
                barmode='group',
                title='Blood Components Comparison',
                height=600,
                showlegend=True,
                yaxis_title='Values',
                xaxis_title='Components',
                xaxis=dict(tickangle=45),
                updatemenus=[dict(
                    type="buttons",
                    showactive=False,
                    buttons=[dict(
                        label="Play",
                        method="animate",
                        args=[None, {"frame": {"duration": 500, "redraw": True},
                                   "fromcurrent": True}]
                    )]
                )]
            )

            # Add animation frames
            frames = []
            for i in range(len(comparative_data['parameters'])):
                frames.append(
                    go.Frame(
                        data=[
                            go.Bar(
                                x=comparative_data['parameters'][:i+1],
                                y=comparative_data['patient_values'][:i+1],
                                marker_color='#0066cc'
                            ),
                            go.Bar(
                                x=comparative_data['parameters'][:i+1],
                                y=comparative_data['normal_values'][:i+1],
                                marker_color='#00cc66'
                            )
                        ]
                    )
                )
            fig.frames = frames

            st.plotly_chart(fig, use_container_width=True)

            # Blood analysis results
            blood_analysis = disease_detector.analyze_blood_report(st.session_state.blood_results['raw_data'])
            conditions = []
            for param, value in st.session_state.blood_results['raw_data'].items():
                ref_range = disease_detector.reference_ranges.get(param)
                if ref_range:
                    if value < ref_range[0]:
                        conditions.append(f"Low {param}: Could indicate {get_condition_description(param, 'low')}")
                    elif value > ref_range[1]:
                        conditions.append(f"High {param}: Could indicate {get_condition_description(param, 'high')}")

            if conditions:
                st.markdown("<div class='metrics-container'>", unsafe_allow_html=True)
                st.subheader("Potential Health Indicators")
                for condition in conditions:
                    st.warning(condition)
                st.markdown("</div>", unsafe_allow_html=True)
        else:
            st.warning("Please complete blood report analysis first.")

    with tab2:
        st.subheader("Hospital Comparison Tool")

        hospitals_df = pd.read_csv("data/hospitals.csv")

        # Add filters
        col1, col2, col3 = st.columns(3)

        with col1:
            selected_state = st.selectbox("Select State", ["All"] + list(hospitals_df['State'].unique()))

        with col2:
            selected_city = st.selectbox("Select City", ["All"] + list(hospitals_df['City'].unique()))

        with col3:
            selected_department = st.selectbox("Select Department", [
                "Surgery Department", "Pediatrics", "Cardiology", 
                "Neurology", "Oncology", "Orthopedics"
            ])

        # Fillter hospitals on selection
        filtered_df = hospitals_df.copy()
        if selected_state != "All":
            filtered_df = filtered_df[filtered_df['State'] == selected_state]
        if selected_city != "All":
            filtered_df = filtered_df[filtered_df['City'] == selected_city]

        # Sort hospitals by selected departmants rating
        filtered_df = filtered_df.sort_values(by=[selected_department, 'Rating_Service'], ascending=[True, False])

        col1, col2 = st.columns(2)

        with col1:
            hospital1 = st.selectbox("Select First Hospital", filtered_df['Hospital_Name'].unique(), key='h1')

        with col2:
            hospital2 = st.selectbox("Select Second Hospital", filtered_df['Hospital_Name'].unique(), key='h2')

        if hospital1 and hospital2:
            
            departments = ['Surgery Department', 'Pediatrics', 'Cardiology', 'Neurology', 'Oncology']
            h1_data = hospitals_df[hospitals_df['Hospital_Name'] == hospital1][departments].iloc[0]
            h2_data = hospitals_df[hospitals_df['Hospital_Name'] == hospital2][departments].iloc[0]

            fig_price = go.Figure()
            fig_price.add_trace(go.Scatter(
                x=departments,
                y=h1_data,
                name=hospital1,
                line=dict(color='#0066cc', width=3)
            ))
            fig_price.add_trace(go.Scatter(
                x=departments,
                y=h2_data,
                name=hospital2,
                line=dict(color='#00cc66', width=3)
            ))

            fig_price.update_layout(
                title='Price Comparison by Department',
                height=500,
                yaxis_title='Price (INR)',
                xaxis_title='Departments',
                xaxis=dict(tickangle=45)
            )

            st.plotly_chart(fig_price, use_container_width=True)

          
            ratings = ['Rating_Service', 'Medicine_Rating']
            h1_ratings = hospitals_df[hospitals_df['Hospital_Name'] == hospital1][ratings].iloc[0]
            h2_ratings = hospitals_df[hospitals_df['Hospital_Name'] == hospital2][ratings].iloc[0]

            fig_rating = go.Figure()
            fig_rating.add_trace(go.Scatter(
                x=ratings,
                y=h1_ratings,
                name=hospital1,
                line=dict(color='#0066cc', width=3),
                mode='lines+markers'
            ))
            fig_rating.add_trace(go.Scatter(
                x=ratings,
                y=h2_ratings,
                name=hospital2,
                line=dict(color='#00cc66', width=3),
                mode='lines+markers'
            ))

            fig_rating.update_layout(
                title='Rating Comparison',
                height=400,
                yaxis_title='Rating',
                yaxis=dict(range=[0, 5])
            )

            st.plotly_chart(fig_rating, use_container_width=True)

else:  
    st.title("Help & Support")
    st.write("Welcome to MedAI! Here's how to use our platform:")

    st.subheader("X-ray Analysis")
    st.write("1. Upload your X-ray image (PNG, JPG, or JPEG format)")
    st.write("2. Select the relevant department")
    st.write("3. View the analysis results and heatmap visualization")

    st.subheader("Blood Report Analysis")
    st.write("1. Upload your blood test report (PDF format)")
    st.write("2. Review the comprehensive analysis")
    st.write("3. Compare your results with normal ranges")

    st.subheader("Need Assistance?")
    st.write("Contact our support team at support@medai.com")


st.markdown("---")
st.markdown("<p style='text-align: center; color: #666666;'>© 2024 MedBridge | Powered by ML</p>", unsafe_allow_html=True)

def get_condition_description(param, level):
    conditions = {
        'WBC Count': {
            'high': 'Infection, inflammation, leukemia, stress, steroid use, smoking',
            'low': 'Viral infections, bone marrow disorders, autoimmune diseases, chemotherapy, severe infections (sepsis)'
        },
        'Hemoglobin': {
            'high': 'Dehydration, lung disease, smoking, high altitudes, polycythemia vera',
            'low': 'Iron deficiency, chronic disease, blood loss, bone marrow disorders, kidney disease'
        },
        'RBC Count': {
            'high': 'Dehydration, lung disease, high altitude, heart disease, polycythemia vera',
            'low': 'Blood loss, iron deficiency, bone marrow failure, chronic kidney disease'
        },
        'Hematocrit': {
            'high': 'Dehydration, polycythemia, cardiovascular disease',
            'low': 'Anemia, blood loss, nutritional deficiencies'
        },
        'MCV': {
            'high': 'Vitamin B12 deficiency, folate deficiency',
            'low': 'Iron deficiency, thalassemia'
        },
        'MCH': {
            'high': 'Folate deficiency, vitamin B12 deficiency',
            'low': 'Iron deficiency, chronic disease'
        },
        'MCHC': {
            'high': 'Hereditary spherocytosis',
            'low': 'Iron deficiency anemia'
        },
        'RDW': {
            'high': 'Iron deficiency, vitamin B12 deficiency',
            'low': 'Chronic anemia'
        },
        'Platelet Count': {
            'high': 'Inflammation, cancer, iron deficiency, infection',
            'low': 'Bone marrow problems, viral infections, autoimmune diseases'
        },
        'ESR': {
            'high': 'Infection, inflammation, cancer, chronic disease',
            'low': 'Polycythemia vera, sickle cell disease'
        }
    }
    return conditions.get(param, {}).get(level, 'abnormal levels')